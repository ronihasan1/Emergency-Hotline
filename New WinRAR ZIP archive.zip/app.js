const serviceCard = document.querySelectorAll('.service_card');
const serviceName = document.querySelectorAll('.service_name');
const serviceNumber = document.querySelectorAll('.service_number');

